"use client";

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

interface SideDrawerProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

export function SideDrawer({ open, onClose, title, children }: SideDrawerProps) {
  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 animate-in fade-in duration-200"
        aria-hidden="true"
      />

      {/* Drawer Panel */}
      <div
        className={cn(
          "fixed top-3 right-3 bottom-3 w-[min(90vw,440px)]",
          "bg-card border border-border rounded-2xl shadow-2xl",
          "z-50 flex flex-col overflow-hidden",
          "animate-in slide-in-from-right duration-300"
        )}
        role="dialog"
        aria-modal="true"
        aria-labelledby="drawer-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-secondary/50">
          <h2
            id="drawer-title"
            className="text-sm font-semibold text-foreground tracking-wide uppercase"
          >
            {title}
          </h2>
          <button
            onClick={onClose}
            className={cn(
              "flex items-center justify-center w-8 h-8 rounded-lg",
              "bg-card border border-border text-muted-foreground",
              "hover:bg-secondary hover:text-foreground hover:border-border",
              "transition-all duration-150",
              "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
            )}
            aria-label="Close drawer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">{children}</div>
      </div>
    </>
  );
}
