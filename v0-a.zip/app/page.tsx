"use client";

import { useState } from "react";
import { TabBar, type TabId } from "@/components/tab-bar";
import { SideDrawer } from "@/components/side-drawer";
import { TaskEditPanel, type Task } from "@/components/task-edit-panel";
import type { ProjectPickerProject } from "@/components/project-picker";
import { Settings, Bell, Search, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

// Sample data
const sampleProjects: ProjectPickerProject[] = [
  { id: "1", name: "Website Redesign", status: "active" },
  { id: "2", name: "Mobile App", status: "active" },
  { id: "3", name: "API Integration", status: "active" },
  { id: "4", name: "Legacy Migration", status: "on_hold" },
];

const sampleTask: Task = {
  id: "task-1",
  title: "Implement user authentication flow",
  notes: "Need to integrate with OAuth provider and set up session management.",
  classification: "boulder",
  priority: "high",
  projectId: "1",
  deadline: "2026-04-15T14:00",
  recurrence: { freq: "weekly", days: ["mon", "wed", "fri"] },
};

const sampleTasks: Task[] = [
  sampleTask,
  {
    id: "task-2",
    title: "Review pull requests",
    notes: "",
    classification: "pebble",
    priority: "med",
  },
  {
    id: "task-3",
    title: "Design system documentation",
    notes: "Update component specs and usage guidelines",
    classification: "rock",
    priority: "low",
    projectId: "1",
  },
  {
    id: "task-4",
    title: "Performance optimization audit",
    notes: "",
    classification: "boulder",
    priority: "high",
    projectId: "2",
  },
];

export default function DashboardDemo() {
  const [activeTab, setActiveTab] = useState<TabId>("today");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const tabs = [
    { id: "today" as TabId, label: "Today", badge: 4 },
    { id: "icebox" as TabId, label: "Icebox", badge: 12 },
    { id: "projects" as TabId, label: "Projects" },
  ];

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
  };

  const classificationStyles = {
    boulder: "border-l-rose-500",
    rock: "border-l-amber-500",
    pebble: "border-l-sky-500",
  };

  const priorityBadge = {
    high: "bg-red-100 text-red-700",
    med: "bg-amber-100 text-amber-700",
    low: "bg-sky-100 text-sky-700",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-card border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">T</span>
            </div>
            <h1 className="text-lg font-semibold text-foreground">TaskFlow</h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              className={cn(
                "flex items-center justify-center w-9 h-9 rounded-lg",
                "text-muted-foreground hover:text-foreground hover:bg-secondary",
                "transition-colors duration-150"
              )}
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              className={cn(
                "flex items-center justify-center w-9 h-9 rounded-lg",
                "text-muted-foreground hover:text-foreground hover:bg-secondary",
                "transition-colors duration-150"
              )}
            >
              <Bell className="w-5 h-5" />
            </button>
            <button
              onClick={() => setDrawerOpen(true)}
              className={cn(
                "flex items-center justify-center w-9 h-9 rounded-lg",
                "text-muted-foreground hover:text-foreground hover:bg-secondary",
                "transition-colors duration-150"
              )}
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Bar */}
        <TabBar tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-foreground">
              {activeTab === "today" && "Today"}
              {activeTab === "icebox" && "Icebox"}
              {activeTab === "projects" && "Projects"}
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {activeTab === "today" && "Tasks scheduled for today"}
              {activeTab === "icebox" && "Tasks saved for later"}
              {activeTab === "projects" && "Organize by project"}
            </p>
          </div>

          <button
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg",
              "bg-primary text-primary-foreground font-medium text-sm",
              "hover:bg-primary/90 transition-colors duration-150",
              "shadow-sm"
            )}
          >
            <Plus className="w-4 h-4" />
            Add Task
          </button>
        </div>

        {/* Task List */}
        <div className="space-y-3">
          {sampleTasks.map((task) => (
            <div key={task.id}>
              <div
                onClick={() => handleTaskClick(task)}
                className={cn(
                  "bg-card border border-border rounded-xl p-4 cursor-pointer",
                  "hover:shadow-md hover:border-primary/30 transition-all duration-200",
                  "border-l-4",
                  classificationStyles[task.classification]
                )}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate">
                      {task.title}
                    </h3>
                    {task.notes && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                        {task.notes}
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      {task.priority && (
                        <span
                          className={cn(
                            "px-2 py-0.5 text-xs font-medium rounded-full capitalize",
                            priorityBadge[task.priority]
                          )}
                        >
                          {task.priority}
                        </span>
                      )}
                      {task.projectId && (
                        <span className="text-xs text-muted-foreground">
                          {sampleProjects.find((p) => p.id === task.projectId)?.name}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Inline Edit Panel */}
              {selectedTask?.id === task.id && (
                <TaskEditPanel
                  task={task}
                  onClose={() => setSelectedTask(null)}
                  onComplete={(id) => console.log("Complete:", id)}
                  onIcebox={(id) => console.log("Icebox:", id)}
                  projects={sampleProjects}
                  onCreateProject={async (name) => ({
                    id: Date.now().toString(),
                    name,
                    status: "active",
                  })}
                  updateTask={async ({ id, data }) =>
                    console.log("Update:", id, data)
                  }
                  deleteTask={(id) => console.log("Delete:", id)}
                />
              )}
            </div>
          ))}
        </div>
      </main>

      {/* Side Drawer */}
      <SideDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title="Settings"
      >
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">
              Preferences
            </h3>
            <div className="space-y-3">
              {["Dark mode", "Notifications", "Compact view"].map((item) => (
                <label
                  key={item}
                  className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 cursor-pointer hover:bg-secondary transition-colors"
                >
                  <span className="text-sm text-foreground">{item}</span>
                  <div className="w-10 h-6 bg-muted rounded-full relative">
                    <div className="absolute left-1 top-1 w-4 h-4 bg-card rounded-full shadow-sm" />
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">
              Account
            </h3>
            <div className="p-4 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-semibold">JD</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">John Doe</p>
                  <p className="text-xs text-muted-foreground">
                    john@example.com
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </SideDrawer>
    </div>
  );
}
