"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
  X,
  Trash2,
  Check,
  Snowflake,
  Calendar,
  Clock,
  Plus,
  Repeat,
  FileText,
  FolderOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ProjectPicker, type ProjectPickerProject } from "./project-picker";

// Types (normally imported from your types file)
export type Classification = "boulder" | "rock" | "pebble";
export type Priority = "high" | "med" | "low";

export interface RecurrenceRule {
  freq: string;
  days?: string[];
  interval?: number;
  periodUnit?: "hours" | "days" | "weeks";
  customUnit?: "weekly" | "monthly";
}

export interface Task {
  id: string;
  title: string;
  notes: string;
  classification: Classification;
  priority?: Priority;
  projectId?: string;
  deadline?: string | null;
  recurrence?: RecurrenceRule | null;
}

interface TaskEditPanelProps {
  task: Task;
  onClose: () => void;
  onComplete?: (id: string) => void;
  onIcebox?: (id: string) => void;
  projects?: ProjectPickerProject[];
  onCreateProject?: (name: string) => Promise<ProjectPickerProject>;
  updateTask?: (params: { id: string; data: any }) => Promise<void>;
  deleteTask?: (id: string) => void;
}

const ALL_DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;
const DAY_LABELS: Record<string, string> = {
  mon: "M",
  tue: "T",
  wed: "W",
  thu: "Th",
  fri: "F",
  sat: "Sa",
  sun: "Su",
};

type RecurrenceMode =
  | ""
  | "daily"
  | "weekly"
  | "monthly"
  | "yearly"
  | "periodically"
  | "custom";

const INDEX_TO_DAY = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

function dayOfWeekFromDate(dateStr: string): string {
  try {
    return INDEX_TO_DAY[new Date(dateStr + "T12:00:00").getDay()];
  } catch {
    return "mon";
  }
}

function recurrenceToMode(rec: RecurrenceRule | null): RecurrenceMode {
  if (!rec) return "";
  return rec.freq as RecurrenceMode;
}

function parseDeadline(deadline: string | null): { date: string; time: string } {
  if (!deadline) return { date: "", time: "" };
  try {
    const d = new Date(deadline);
    const date = d.toISOString().slice(0, 10);
    const time =
      d.getHours() || d.getMinutes() ? d.toTimeString().slice(0, 5) : "";
    return { date, time };
  } catch {
    return { date: "", time: "" };
  }
}

interface EditableTaskState {
  title: string;
  notes: string;
  classification: Classification;
  priority: Priority;
  projectId: string | null;
  deadline: string | null;
  recurrence: RecurrenceRule | null;
}

function buildEditableState(task: Task): EditableTaskState {
  const { date, time } = parseDeadline(task.deadline ?? null);
  const deadlineStr = date ? (time ? `${date}T${time}` : date) : null;
  return {
    title: task.title,
    notes: task.notes,
    classification: task.classification,
    priority: task.priority || "low",
    projectId: task.projectId || null,
    deadline: deadlineStr,
    recurrence: task.recurrence || null,
  };
}

export function TaskEditPanel({
  task,
  onClose,
  onComplete,
  onIcebox,
  projects = [],
  onCreateProject,
  updateTask,
  deleteTask,
}: TaskEditPanelProps) {
  const initialDeadline = parseDeadline(task.deadline ?? null);
  const [title, setTitle] = useState(task.title);
  const [notes, setNotes] = useState(task.notes);
  const [classification, setClassification] = useState<Classification>(
    task.classification
  );
  const [priority, setPriority] = useState<Priority>(task.priority || "low");
  const [projectId, setProjectId] = useState(task.projectId || "");
  const [deadlineDate, setDeadlineDate] = useState(initialDeadline.date);
  const [deadlineTime, setDeadlineTime] = useState(initialDeadline.time);
  const [showTime, setShowTime] = useState(!!initialDeadline.time);

  // Progressive disclosure: which optional fields are shown
  const [showNotes, setShowNotes] = useState(!!task.notes);
  const [showProject, setShowProject] = useState(!!task.projectId);
  const [showDeadline, setShowDeadline] = useState(!!task.deadline);
  const [showRecurrence, setShowRecurrence] = useState(!!task.recurrence);

  // Recurrence state
  const [recMode, setRecMode] = useState<RecurrenceMode>(
    recurrenceToMode(task.recurrence ?? null)
  );
  const [weeklyDays, setWeeklyDays] = useState<string[]>(
    task.recurrence?.freq === "weekly" && task.recurrence.days
      ? task.recurrence.days
      : []
  );
  const [periodicallyValue, setPeriodicallyValue] = useState(
    task.recurrence?.freq === "periodically"
      ? task.recurrence.interval || 7
      : 7
  );
  const [periodicallyUnit, setPeriodicallyUnit] = useState<
    "hours" | "days" | "weeks"
  >(
    task.recurrence?.freq === "periodically"
      ? task.recurrence.periodUnit || "days"
      : "days"
  );
  const [customUnit, setCustomUnit] = useState<"weekly" | "monthly">(
    task.recurrence?.freq === "custom"
      ? task.recurrence.customUnit || "weekly"
      : "weekly"
  );
  const [customInterval, setCustomInterval] = useState(
    task.recurrence?.freq === "custom" ? task.recurrence.interval || 2 : 2
  );
  const [customDays, setCustomDays] = useState<string[]>(
    task.recurrence?.freq === "custom" && task.recurrence.days
      ? task.recurrence.days
      : []
  );
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [saveState, setSaveState] = useState<
    "idle" | "saving" | "saved" | "error"
  >("idle");
  const autosaveTimeoutRef = useRef<number | null>(null);
  const savedStateRef = useRef<EditableTaskState>(buildEditableState(task));
  const latestSaveIdRef = useRef(0);

  // Auto-resize title textarea
  const titleRef = useRef<HTMLTextAreaElement>(null);
  const autoResize = useCallback((el: HTMLTextAreaElement | null) => {
    if (!el) return;
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
  }, []);
  useEffect(() => {
    autoResize(titleRef.current);
  }, [title, autoResize]);

  const buildRecurrence = useCallback((): RecurrenceRule | null => {
    if (!showRecurrence) return null;
    switch (recMode) {
      case "daily":
        return { freq: "daily" };
      case "weekly":
        return weeklyDays.length > 0
          ? { freq: "weekly", days: weeklyDays }
          : { freq: "weekly" };
      case "monthly":
        return { freq: "monthly" };
      case "yearly":
        return { freq: "yearly" };
      case "periodically":
        return {
          freq: "periodically",
          interval: periodicallyValue,
          periodUnit: periodicallyUnit,
        };
      case "custom": {
        const base: RecurrenceRule = {
          freq: "custom",
          customUnit,
          interval: customInterval,
        };
        if (customUnit === "weekly" && customDays.length > 0)
          base.days = customDays;
        return base;
      }
      default:
        return null;
    }
  }, [
    showRecurrence,
    recMode,
    weeklyDays,
    periodicallyValue,
    periodicallyUnit,
    customUnit,
    customInterval,
    customDays,
  ]);

  const buildCurrentState = useCallback((): EditableTaskState => {
    const deadlineStr =
      showDeadline && deadlineDate
        ? deadlineTime
          ? `${deadlineDate}T${deadlineTime}`
          : deadlineDate
        : null;
    return {
      title,
      notes,
      classification,
      priority,
      projectId: projectId || null,
      deadline: deadlineStr,
      recurrence: buildRecurrence(),
    };
  }, [
    title,
    notes,
    classification,
    priority,
    projectId,
    showDeadline,
    deadlineDate,
    deadlineTime,
    buildRecurrence,
  ]);

  const buildUpdateData = useCallback((current: EditableTaskState) => {
    const data: Record<string, unknown> = {};
    const saved = savedStateRef.current;
    if (current.title !== saved.title) data.title = current.title;
    if (current.notes !== saved.notes) data.notes = current.notes;
    if (current.classification !== saved.classification)
      data.classification = current.classification;
    if (current.priority !== saved.priority) data.priority = current.priority;
    if (current.projectId !== saved.projectId)
      data.projectId = current.projectId;
    if (current.deadline !== saved.deadline) data.deadline = current.deadline;
    if (JSON.stringify(current.recurrence) !== JSON.stringify(saved.recurrence))
      data.recurrence = current.recurrence;
    return data;
  }, []);

  const persistDraft = useCallback(
    async (current: EditableTaskState) => {
      const data = buildUpdateData(current);
      if (Object.keys(data).length === 0) return;

      const saveId = ++latestSaveIdRef.current;
      setSaveState("saving");
      try {
        if (updateTask) {
          await updateTask({ id: task.id, data });
        }
        savedStateRef.current = current;
        if (latestSaveIdRef.current === saveId) {
          setSaveState("saved");
        }
      } catch {
        if (latestSaveIdRef.current === saveId) {
          setSaveState("error");
        }
      }
    },
    [buildUpdateData, task.id, updateTask]
  );

  const flushAutosave = useCallback(() => {
    if (autosaveTimeoutRef.current !== null) {
      window.clearTimeout(autosaveTimeoutRef.current);
      autosaveTimeoutRef.current = null;
    }
    const current = buildCurrentState();
    void persistDraft(current);
  }, [buildCurrentState, persistDraft]);

  useEffect(() => {
    savedStateRef.current = buildEditableState(task);
    setSaveState("idle");
  }, [task.id]);

  useEffect(() => {
    const current = buildCurrentState();
    const data = buildUpdateData(current);
    if (autosaveTimeoutRef.current !== null) {
      window.clearTimeout(autosaveTimeoutRef.current);
      autosaveTimeoutRef.current = null;
    }
    if (Object.keys(data).length === 0) {
      setSaveState((prev) => (prev === "error" ? "error" : prev));
      return;
    }
    autosaveTimeoutRef.current = window.setTimeout(() => {
      autosaveTimeoutRef.current = null;
      void persistDraft(current);
    }, 350);
    return () => {
      if (autosaveTimeoutRef.current !== null) {
        window.clearTimeout(autosaveTimeoutRef.current);
        autosaveTimeoutRef.current = null;
      }
    };
  }, [buildCurrentState, buildUpdateData, persistDraft]);

  useEffect(
    () => () => {
      if (autosaveTimeoutRef.current !== null) {
        window.clearTimeout(autosaveTimeoutRef.current);
        autosaveTimeoutRef.current = null;
        const current = buildCurrentState();
        void persistDraft(current);
      }
    },
    [buildCurrentState, persistDraft]
  );

  const handleClose = () => {
    flushAutosave();
    onClose();
  };

  const handleDelete = () => {
    if (deleteTask) {
      deleteTask(task.id);
    }
    onClose();
  };

  const handleRecModeChange = (mode: RecurrenceMode) => {
    setRecMode(mode);
    if (mode === "weekly" && weeklyDays.length === 0 && deadlineDate) {
      setWeeklyDays([dayOfWeekFromDate(deadlineDate)]);
    }
    if (
      mode === "custom" &&
      customUnit === "weekly" &&
      customDays.length === 0 &&
      deadlineDate
    ) {
      setCustomDays([dayOfWeekFromDate(deadlineDate)]);
    }
    if (mode === "periodically") {
      if (periodicallyUnit === "hours") setPeriodicallyValue(24);
      else if (periodicallyUnit === "weeks") setPeriodicallyValue(2);
      else setPeriodicallyValue(3);
    }
  };

  const handlePeriodicallyUnitChange = (unit: "hours" | "days" | "weeks") => {
    setPeriodicallyUnit(unit);
    if (unit === "hours") setPeriodicallyValue(24);
    else if (unit === "weeks") setPeriodicallyValue(2);
    else setPeriodicallyValue(3);
  };

  const toggleDay = (
    day: string,
    days: string[],
    setDays: (d: string[]) => void
  ) => {
    if (days.includes(day) && days.length <= 1) return;
    setDays(
      days.includes(day) ? days.filter((d) => d !== day) : [...days, day]
    );
  };

  const removeField = (
    field: "notes" | "project" | "deadline" | "recurrence"
  ) => {
    switch (field) {
      case "notes":
        setShowNotes(false);
        setNotes("");
        break;
      case "project":
        setShowProject(false);
        setProjectId("");
        break;
      case "deadline":
        setShowDeadline(false);
        setDeadlineDate("");
        setDeadlineTime("");
        setShowRecurrence(false);
        setRecMode("");
        break;
      case "recurrence":
        setShowRecurrence(false);
        setRecMode("");
        break;
    }
  };

  // Collect which add-field links to show
  const addLinks: { label: string; icon: React.ReactNode; action: () => void }[] = [];
  if (!showNotes)
    addLinks.push({
      label: "Notes",
      icon: <FileText className="w-3.5 h-3.5" />,
      action: () => setShowNotes(true),
    });
  if (!showProject)
    addLinks.push({
      label: "Project",
      icon: <FolderOpen className="w-3.5 h-3.5" />,
      action: () => setShowProject(true),
    });
  if (!showDeadline)
    addLinks.push({
      label: "Deadline",
      icon: <Calendar className="w-3.5 h-3.5" />,
      action: () => setShowDeadline(true),
    });
  if (showDeadline && !showRecurrence)
    addLinks.push({
      label: "Recurrence",
      icon: <Repeat className="w-3.5 h-3.5" />,
      action: () => {
        setShowRecurrence(true);
        if (!recMode) handleRecModeChange("weekly");
      },
    });

  const classificationConfig = {
    boulder: { label: "Boulder", color: "bg-rose-500" },
    rock: { label: "Rock", color: "bg-amber-500" },
    pebble: { label: "Pebble", color: "bg-sky-500" },
  };

  const priorityConfig = {
    high: { label: "High", color: "bg-red-500", ring: "ring-red-500/20" },
    med: { label: "Med", color: "bg-amber-500", ring: "ring-amber-500/20" },
    low: { label: "Low", color: "bg-sky-500", ring: "ring-sky-500/20" },
  };

  return (
    <div
      className="p-4 bg-secondary/30 border-t border-border animate-in slide-in-from-top-2 duration-200"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Title */}
      <textarea
        ref={titleRef}
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        rows={1}
        className={cn(
          "w-full px-3 py-2 mb-4 text-base font-semibold text-foreground",
          "bg-card border border-input rounded-lg resize-none overflow-hidden",
          "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
          "transition-all duration-150 placeholder:text-muted-foreground"
        )}
        placeholder="Task title..."
      />

      {/* Classification Toggle */}
      <div className="mb-4">
        <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
          Type
        </label>
        <div className="flex gap-2">
          {(["boulder", "rock", "pebble"] as const).map((type) => {
            const active = classification === type;
            const config = classificationConfig[type];
            return (
              <button
                key={type}
                onClick={() => setClassification(type)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium",
                  "border transition-all duration-150",
                  active
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-card text-secondary-foreground border-input hover:bg-secondary hover:border-border"
                )}
              >
                <span
                  className={cn(
                    "w-2 h-2 rounded-full",
                    active ? "bg-primary-foreground/50" : config.color
                  )}
                />
                {config.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Priority Toggle */}
      <div className="mb-4">
        <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
          Priority
        </label>
        <div className="flex gap-2">
          {(["high", "med", "low"] as const).map((p) => {
            const active = priority === p;
            const config = priorityConfig[p];
            return (
              <button
                key={p}
                onClick={() => setPriority(p)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium",
                  "border transition-all duration-150",
                  active
                    ? `${config.color} text-white border-transparent shadow-sm`
                    : "bg-card text-secondary-foreground border-input hover:bg-secondary"
                )}
              >
                {config.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Notes - Progressive */}
      {showNotes && (
        <div className="relative mb-4">
          <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            Notes
          </label>
          <div className="relative">
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes..."
              className={cn(
                "w-full min-h-[80px] px-3 py-2 text-sm text-foreground",
                "bg-card border border-input rounded-lg resize-y",
                "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
                "transition-all duration-150 placeholder:text-muted-foreground"
              )}
            />
            <button
              onClick={() => removeField("notes")}
              className="absolute top-2 right-2 p-1 text-muted-foreground hover:text-foreground transition-colors"
              title="Remove notes"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Project - Progressive */}
      {showProject && (
        <div className="mb-4">
          <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            Project
          </label>
          <div className="flex items-center gap-2">
            <ProjectPicker
              projects={projects}
              value={projectId}
              onChange={setProjectId}
              onCreateProject={onCreateProject}
            />
            <button
              onClick={() => removeField("project")}
              className="p-2 text-muted-foreground hover:text-foreground transition-colors"
              title="Remove project"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Deadline - Progressive */}
      {showDeadline && (
        <div className="mb-4">
          <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            Deadline
          </label>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <input
                type="date"
                value={deadlineDate}
                onChange={(e) => setDeadlineDate(e.target.value)}
                className={cn(
                  "h-9 pl-9 pr-3 text-sm rounded-lg",
                  "bg-card border border-input text-foreground",
                  "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
                  "transition-all duration-150"
                )}
              />
            </div>
            {showTime ? (
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input
                  type="time"
                  value={deadlineTime}
                  onChange={(e) => setDeadlineTime(e.target.value)}
                  className={cn(
                    "h-9 pl-9 pr-3 text-sm rounded-lg",
                    "bg-card border border-input text-foreground",
                    "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
                    "transition-all duration-150"
                  )}
                />
              </div>
            ) : (
              <button
                onClick={() => setShowTime(true)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add time
              </button>
            )}
            <button
              onClick={() => removeField("deadline")}
              className="p-2 text-muted-foreground hover:text-foreground transition-colors"
              title="Remove deadline"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Recurrence - Progressive */}
      {showRecurrence && showDeadline && (
        <div className="mb-4">
          <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            Repeats
          </label>
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <select
              value={recMode}
              onChange={(e) =>
                handleRecModeChange(e.target.value as RecurrenceMode)
              }
              className={cn(
                "h-9 px-3 text-sm rounded-lg appearance-none",
                "bg-card border border-input text-foreground",
                "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
                "transition-all duration-150"
              )}
            >
              <option value="">Never</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="yearly">Yearly</option>
              <option value="periodically">Periodically</option>
              <option value="custom">Custom</option>
            </select>
            <button
              onClick={() => removeField("recurrence")}
              className="p-2 text-muted-foreground hover:text-foreground transition-colors"
              title="Remove recurrence"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Weekly day picker */}
          {recMode === "weekly" && (
            <div className="flex items-center gap-1.5 mb-2">
              <span className="text-xs text-muted-foreground mr-1">On:</span>
              {ALL_DAYS.map((day) => (
                <button
                  key={day}
                  onClick={() => toggleDay(day, weeklyDays, setWeeklyDays)}
                  className={cn(
                    "w-8 h-7 text-xs font-medium rounded-md border transition-all duration-150",
                    weeklyDays.includes(day)
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card text-secondary-foreground border-input hover:bg-secondary"
                  )}
                >
                  {DAY_LABELS[day]}
                </button>
              ))}
            </div>
          )}

          {/* Periodically */}
          {recMode === "periodically" && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-muted-foreground">Reschedule</span>
              <input
                type="number"
                min={1}
                value={periodicallyValue}
                onChange={(e) =>
                  setPeriodicallyValue(Math.max(1, parseInt(e.target.value) || 1))
                }
                className={cn(
                  "w-16 h-9 px-2 text-sm text-center rounded-lg",
                  "bg-card border border-input text-foreground",
                  "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                )}
              />
              <select
                value={periodicallyUnit}
                onChange={(e) =>
                  handlePeriodicallyUnitChange(e.target.value as any)
                }
                className={cn(
                  "h-9 px-3 text-sm rounded-lg appearance-none",
                  "bg-card border border-input text-foreground",
                  "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                )}
              >
                <option value="hours">hours</option>
                <option value="days">days</option>
                <option value="weeks">weeks</option>
              </select>
              <span className="text-xs text-muted-foreground">
                after completion
              </span>
            </div>
          )}

          {/* Custom */}
          {recMode === "custom" && (
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-muted-foreground">Every</span>
                <input
                  type="number"
                  min={1}
                  max={26}
                  value={customInterval}
                  onChange={(e) =>
                    setCustomInterval(
                      Math.min(26, Math.max(1, parseInt(e.target.value) || 1))
                    )
                  }
                  className={cn(
                    "w-16 h-9 px-2 text-sm text-center rounded-lg",
                    "bg-card border border-input text-foreground",
                    "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  )}
                />
                <select
                  value={customUnit}
                  onChange={(e) =>
                    setCustomUnit(e.target.value as "weekly" | "monthly")
                  }
                  className={cn(
                    "h-9 px-3 text-sm rounded-lg appearance-none",
                    "bg-card border border-input text-foreground",
                    "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  )}
                >
                  <option value="weekly">
                    {customInterval === 1 ? "week" : "weeks"}
                  </option>
                  <option value="monthly">
                    {customInterval === 1 ? "month" : "months"}
                  </option>
                </select>
              </div>
              {customUnit === "weekly" && (
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-muted-foreground mr-1">On:</span>
                  {ALL_DAYS.map((day) => (
                    <button
                      key={day}
                      onClick={() => toggleDay(day, customDays, setCustomDays)}
                      className={cn(
                        "w-8 h-7 text-xs font-medium rounded-md border transition-all duration-150",
                        customDays.includes(day)
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-card text-secondary-foreground border-input hover:bg-secondary"
                      )}
                    >
                      {DAY_LABELS[day]}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Add-field links */}
      {addLinks.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {addLinks.map((link) => (
            <button
              key={link.label}
              onClick={link.action}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium",
                "text-muted-foreground hover:text-foreground hover:bg-secondary",
                "border border-dashed border-input transition-all duration-150"
              )}
            >
              {link.icon}
              {link.label}
            </button>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2 pt-4 border-t border-border">
        {!confirmingDelete ? (
          <button
            onClick={() => setConfirmingDelete(true)}
            className={cn(
              "flex items-center justify-center w-9 h-9 rounded-lg",
              "bg-red-50 text-red-600 border border-red-200",
              "hover:bg-red-100 hover:border-red-300 transition-all duration-150"
            )}
            title="Delete task"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleDelete}
            className={cn(
              "flex items-center justify-center h-9 px-4 rounded-lg",
              "bg-red-600 text-white font-medium text-sm",
              "hover:bg-red-700 transition-all duration-150"
            )}
            title="Confirm delete"
          >
            Delete
          </button>
        )}
        {onComplete && (
          <button
            onClick={() => {
              flushAutosave();
              onComplete(task.id);
              onClose();
            }}
            className={cn(
              "flex items-center justify-center w-9 h-9 rounded-lg",
              "bg-emerald-50 text-emerald-600 border border-emerald-200",
              "hover:bg-emerald-100 hover:border-emerald-300 transition-all duration-150"
            )}
            title="Complete"
          >
            <Check className="w-4 h-4" />
          </button>
        )}
        {onIcebox && (
          <button
            onClick={() => {
              flushAutosave();
              onIcebox(task.id);
              onClose();
            }}
            className={cn(
              "flex items-center justify-center w-9 h-9 rounded-lg",
              "bg-secondary text-muted-foreground border border-input",
              "hover:bg-muted hover:text-foreground transition-all duration-150"
            )}
            title="Icebox"
          >
            <Snowflake className="w-4 h-4" />
          </button>
        )}

        {/* Save Status */}
        <div className="text-xs text-muted-foreground min-w-[60px]">
          {saveState === "saving" && (
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
              Saving...
            </span>
          )}
          {saveState === "saved" && (
            <span className="flex items-center gap-1.5 text-emerald-600">
              <Check className="w-3 h-3" />
              Saved
            </span>
          )}
          {saveState === "error" && (
            <span className="text-red-500">Save failed</span>
          )}
        </div>

        <div className="flex-1" />

        <button
          onClick={handleClose}
          className={cn(
            "flex items-center justify-center w-9 h-9 rounded-lg",
            "bg-secondary text-muted-foreground border border-input",
            "hover:bg-muted hover:text-foreground transition-all duration-150"
          )}
          title="Close"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
